package net.krypton.client.module.impl.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.krypton.client.module.ClientModule;
import net.krypton.client.module.ModuleCategory;
import net.krypton.client.module.ModuleRegistry;
import net.krypton.client.module.setting.BooleanSetting;
import net.krypton.client.module.setting.ColorSetting;
import net.krypton.client.module.setting.NumberSetting;
import net.minecraft.class_1657;
import net.minecraft.class_746;

@Environment(EnvType.CLIENT)
public final class RadarModule extends ClientModule {
   private final NumberSetting range = this.addSetting("range", new NumberSetting("Range", 48.0F, 8.0F, 256.0F).step(1.0F));
   private final NumberSetting size = this.addSetting("size", new NumberSetting("Size", 150.0F, 80.0F, 320.0F).step(1.0F));
   private final BooleanSetting rotate = this.addSetting("rotate", new BooleanSetting("Rotate", true));
   private final ColorSetting dotColor = this.addSetting("dot-color", new ColorSetting("Player Color", -47814));

   public RadarModule() {
      super("radar", "Radar", "A round radar of the players around you.", ModuleCategory.CLIENT);
   }

   public static RadarModule get() {
      return ModuleRegistry.get(RadarModule.class);
   }

   public static boolean shouldShowHud() {
      RadarModule module = get();
      return module != null && module.isEnabled();
   }

   public float range() {
      return this.range.get();
   }

   public float size() {
      return this.size.get();
   }

   public boolean rotate() {
      return this.rotate.get();
   }

   public int dotColor() {
      return this.dotColor.argb();
   }

   public boolean shows(class_1657 player) {
      return !(player instanceof class_746) && !player.method_31481() && !player.method_29504() && !player.method_7325();
   }
}
