package net.krypton.client.module.impl.movement;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.krypton.client.module.ClientModule;
import net.krypton.client.module.ModuleCategory;
import net.krypton.client.module.setting.ModeSetting;
import net.minecraft.class_310;
import net.minecraft.class_746;

@Environment(EnvType.CLIENT)
public final class SneakModule extends ClientModule {
   public static volatile SneakModule active;
   private final ModeSetting mode = this.addSetting("mode", new ModeSetting("Mode", "Vanilla", "Packet", "Vanilla"));

   public SneakModule() {
      super("sneak", "Sneak", "Sneaks for you.", ModuleCategory.MOVEMENT);
   }

   @Override
   protected void onEnable() {
      active = this;
   }

   @Override
   protected void onDisable() {
      active = null;
   }

   public boolean doPacket() {
      return this.isEnabled() && this.mode.is("Packet") && !isFlying();
   }

   public boolean doVanilla() {
      return this.isEnabled() && this.mode.is("Vanilla") && !isFlying();
   }

   private static boolean isFlying() {
      class_746 player = class_310.method_1551().field_1724;
      return player == null || player.method_31549().field_7479;
   }
}
