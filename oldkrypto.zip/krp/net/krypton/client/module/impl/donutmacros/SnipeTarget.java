package net.krypton.client.module.impl.donutmacros;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.krypton.client.module.setting.StringSetting;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_7923;

@Environment(EnvType.CLIENT)
final class SnipeTarget {
   private static final Pattern DURATION = Pattern.compile("(\\d+)\\s*([dhms])");
   final class_1792 item;
   final boolean shard;
   final SnipeTarget.Preset preset;
   final String displayName;
   final String search;
   final List<Product.Enchant> enchants;
   final boolean exactEnchants;
   final long maxPrice;
   final int minMinutes;

   private SnipeTarget(
      class_1792 item,
      boolean shard,
      SnipeTarget.Preset preset,
      String displayName,
      String search,
      List<Product.Enchant> enchants,
      boolean exactEnchants,
      long maxPrice,
      int minMinutes
   ) {
      this.item = item;
      this.shard = shard;
      this.preset = preset;
      this.displayName = displayName;
      this.search = search;
      this.enchants = enchants;
      this.exactEnchants = exactEnchants;
      this.maxPrice = maxPrice;
      this.minMinutes = minMinutes;
   }

   static SnipeTarget parse(String rawItem, String rawEnchants, boolean exact, long maxPrice, int minMinutes) {
      List<Product.Enchant> enchants = Product.parseEnchants(rawEnchants);
      SnipeTarget.Preset preset = SnipeTarget.Preset.of(rawItem);
      if (preset != null) {
         return new SnipeTarget(preset.item, true, preset, preset.label, preset.search, enchants, exact, maxPrice, minMinutes);
      }

      String text = rawItem == null ? "" : rawItem.trim().toLowerCase(Locale.ROOT).replace(' ', '_');
      if (text.startsWith("minecraft:")) {
         text = text.substring("minecraft:".length());
      }

      boolean shard = text.startsWith("shard_");
      class_1792 item = Product.resolveItem(shard ? "netherite_" + text.substring("shard_".length()) : text);
      if (item == null) {
         return null;
      }

      String name = shard ? "Shard " + capitalize(text.substring("shard_".length())) : new class_1799(item).method_7964().getString();
      return new SnipeTarget(item, shard, null, name, Product.searchText(item), enchants, exact, maxPrice, shard ? minMinutes : 0);
   }

   private static String capitalize(String path) {
      StringBuilder out = new StringBuilder();

      for (String word : path.split("_")) {
         if (!word.isEmpty()) {
            if (out.length() > 0) {
               out.append(' ');
            }

            out.append(Character.toUpperCase(word.charAt(0))).append(word.substring(1));
         }
      }

      return out.toString();
   }

   boolean sameKind(class_1799 stack) {
      if (!stack.method_7960() && stack.method_31574(this.item)) {
         String name = ServerText.key(stack.method_7964().getString());
         if (this.preset != null) {
            if (!name.contains(this.preset.keyword)) {
               return false;
            }

            if (!this.preset.exclude.isEmpty() && name.contains(this.preset.exclude)) {
               return false;
            }
         } else if (name.contains("shard") != this.shard) {
            return false;
         }

         return this.enchants.isEmpty() || Product.enchantsMatch(stack, this.enchants, this.exactEnchants);
      } else {
         return false;
      }
   }

   boolean matches(class_1799 stack) {
      if (!this.sameKind(stack)) {
         return false;
      } else {
         return this.preset != null ? minutesLeft(stack) >= Math.max(0, this.minMinutes) : this.minMinutes <= 0 || minutesLeft(stack) >= this.minMinutes;
      }
   }

   static int minutesLeft(class_1799 stack) {
      for (String line : ServerText.lore(stack)) {
         String clean = ServerText.normalize(line);
         if (clean.contains("self destruct") || clean.contains("expire")) {
            Matcher matcher = DURATION.matcher(clean);
            int minutes = 0;
            boolean found = false;

            while (matcher.find()) {
               found = true;
               int value = Integer.parseInt(matcher.group(1));
               switch (matcher.group(2)) {
                  case "d":
                     minutes += value * 1440;
                     break;
                  case "h":
                     minutes += value * 60;
                     break;
                  case "m":
                     minutes += value;
               }
            }

            if (found) {
               return minutes;
            }
         }
      }

      return -1;
   }

   Product product(long sellPrice) {
      return new Product(
         this.item,
         class_7923.field_41178.method_10221(this.item).method_12832(),
         this.search,
         this.displayName,
         sellPrice,
         this.enchants,
         false,
         1,
         false,
         1L,
         1L,
         0L,
         this::sameKind
      );
   }

   String describe() {
      StringBuilder text = new StringBuilder(this.displayName);
      if (!this.enchants.isEmpty()) {
         StringBuilder names = new StringBuilder();

         for (Product.Enchant enchant : this.enchants) {
            if (names.length() > 0) {
               names.append(", ");
            }

            names.append(enchant.label());
         }

         text.append(" (").append(this.exactEnchants ? "exactly " : "at least ").append(names).append(')');
      }

      return text.toString();
   }

   @Environment(EnvType.CLIENT)
   enum Preset {
      SELL_AXE("sell_axe", "Sell Axe", class_1802.field_22025, "sell axe", "sell", ""),
      DRILL("drill", "Drill", class_1802.field_22024, "drill", "drill", ""),
      SHARD_AXE("shard_axe", "Shard Axe", class_1802.field_22025, "shard axe", "shard", "sell");

      final String value;
      final String label;
      final class_1792 item;
      final String search;
      final String keyword;
      final String exclude;

      Preset(String value, String label, class_1792 item, String search, String keyword, String exclude) {
         this.value = value;
         this.label = label;
         this.item = item;
         this.search = search;
         this.keyword = keyword;
         this.exclude = exclude;
      }

      static SnipeTarget.Preset of(String raw) {
         String text = raw == null ? "" : raw.trim().toLowerCase(Locale.ROOT).replace(' ', '_');

         for (SnipeTarget.Preset preset : values()) {
            if (preset.value.equals(text)) {
               return preset;
            }
         }

         return null;
      }

      static List<StringSetting.Preset> choices() {
         List<StringSetting.Preset> out = new ArrayList<>();

         for (SnipeTarget.Preset preset : values()) {
            out.add(new StringSetting.Preset(preset.value, preset.label, class_7923.field_41178.method_10221(preset.item).method_12832(), true));
         }

         return out;
      }
   }
}
