package net.krypton.client.gui.mainmenu;

import imgui.ImDrawList;
import imgui.ImFont;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.krypton.client.gui.EgyptDraw;

@Environment(EnvType.CLIENT)
final class DuskPill {
   private static final float BAND = 0.2F;
   private static final float STRIP = 4.0F;

   private DuskPill() {
   }

   static void frame(MenuFrame var0, float var1, float var2, float var3, float var4, float var5, float var6, float var7) {
      KryptonMenuChrome.frame(var0, var1, var2, var3, var4, var5, var6, var7);
   }

   static void halo(MenuFrame c, ImFont font, float x, float y, float track, float hover, String label) {
      if (!(hover <= 0.01F)) {
         float s = c.scale();
         float amount = hover * glow(c);

         for (int ring = 1; ring <= 2; ring++) {
            for (int i = 0; i < 8; i++) {
               double angle = i * Math.PI / 4.0;
               float d = ring * 1.8F * s;
               c.spacedText(
                  c.bg(), font, x + (float)Math.cos(angle) * d, y + (float)Math.sin(angle) * d, track, -12133121, (ring == 1 ? 0.1F : 0.06F) * amount, label
               );
            }
         }
      }
   }

   private static float glow(MenuFrame c) {
      return 0.7F + 0.3F * DuskEmblem.breath(c.time());
   }

   private static void light(ImDrawList dl, float x, float y, float w, float h, float r, float s, float pass, float a) {
      float half = w * 0.2F;
      float pad = 5.0F * s;
      float step = 4.0F * s;
      float centre = x - half + pass * (w + half * 2.0F);
      float start = centre - half;
      int strips = (int)Math.ceil(half * 2.0F / step);

      for (int i = 0; i < strips; i++) {
         float x0 = Math.max(Math.round(start + i * step), x - pad);
         float x1 = Math.min(Math.round(start + (i + 1) * step), x + w + pad);
         float k = DuskEmblem.smooth(1.0F - Math.abs(start + (i + 0.5F) * step - centre) / half);
         if (!(k < 0.02F) && !(x1 <= x0)) {
            dl.pushClipRect(x0, y - pad, x1, y + h + pad, true);
            stroke(dl, x, y, w, h, r, EgyptDraw.col(-12133121, 0.26F * k * a), 8.0F * s);
            stroke(dl, x, y, w, h, r, EgyptDraw.col(-1, 0.42F * k * a), 4.5F * s);
            stroke(dl, x, y, w, h, r, EgyptDraw.col(-1, 0.95F * k * a), Math.max(2.0F, 2.0F * s));
            dl.popClipRect();
         }
      }
   }

   private static void stroke(ImDrawList dl, float x, float y, float w, float h, float r, int color, float thickness) {
      dl.addRect(x, y, x + w, y + h, color, r, 0, thickness);
   }
}
